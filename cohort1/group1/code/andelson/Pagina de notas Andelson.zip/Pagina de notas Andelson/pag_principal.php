<?php 
    // varibles (preparativos)
    
    // -- conexion
    require_once "PHP/config.php";
    $db = new database();
    $conex = $db->conectar();

    // -- sesion
    session_start();

    // datos de la cuenta del usuario
    if (isset($_SESSION['n_usuario']) and isset($_SESSION['i_usuario']) and isset($_SESSION['id_usuario'])){
        $nombre_usuario = $_SESSION['n_usuario'];
        $imagen_usuario =  $_SESSION['i_usuario'];
        $id_usuario =  $_SESSION['id_usuario'];

        // datos de los formularios creados por el usuario
        $query_frm_usuario = $conex->prepare("select * from nombre_bd_usuario where id_user = ?");
        $query_frm_usuario->execute([$id_usuario]);
        
        $resultado_frm_usuario = $query_frm_usuario->fetchAll(PDO::FETCH_ASSOC);
    } else {
        header("location: index.php");
    }
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PORTAL | Pagina principal</title>

    <!-- CSS PERSONALIZADO -->
    <link rel="stylesheet" href="CSS/normalize.css">
    <link rel="stylesheet" href="CSS/pag_principal/estructura_general.css">
    <link rel="stylesheet" href="CSS/pag_principal/menu_vertical.css">
    <link rel="stylesheet" href="CSS/pag_principal/contenedor_areas_encabezado.css"> 
    <link rel="stylesheet" href="CSS/pag_principal/contenedor_areas_frm.css"> 
    <link rel="stylesheet" href="CSS/pag_principal/configuracion.css"> 
    <link rel="stylesheet" href="CSS/pag_principal/frm_usuario.css"> 
    <link rel="stylesheet" href="CSS/pag_principal/noticia.css"> 
    <link rel="stylesheet" href="CSS/pag_principal/notificacion.css"> 
    <link rel="stylesheet" href="CSS/pag_principal/visualizador_noticia.css"> 

    <!-- icono de la pagina -->
    <link rel="icon" href="IMG/logo_app.ico" type="image/x-icon">
</head>
<body>

    <!-- Elementos flotantes -->

    <!-- --- Notificacion --- -->
    <!-- funcionalidad de envio de una respuesta a traves de php -->
    <?php if (isset($_SESSION['icono_n'])){ ?>
    <div class="capa_notificacion ani_entrada_notificacion">
        <div class="contenedor_notificacion" id="contenedor_notificacion">
            <div class="encabezado">
                <i class="<?php echo $_SESSION['icono_n'] ?>"></i>
                <p class="titulo"><?php echo $_SESSION['titulo_n'] ?></p>
            </div>
            
            <p class="contenido"><?php echo $_SESSION['respuesta_n'] ?></p>
            <button class="btn1" id="btn_cerrar_notificacion">Okey</button>
        </div>
    </div>
    <?php
        unset($_SESSION['icono_n'], $_SESSION['titulo_n'], $_SESSION['respuesta_n']); 
        } else { ?>
        <div class="capa_notificacion">
            <div class="contenedor_notificacion" id="contenedor_notificacion">
                <div class="encabezado">
                    <i class=""></i>
                    <p class="titulo">Titulo</p>
                </div>
                
                <p class="contenido">Contenido</p>
                <button class="btn1" id="btn_cerrar_notificacion">Aceptar</button>
            </div>
        </div>
    <?php } ?>

    <!-- --- Visualizacion de noticia --- -->
     <div class="visualizador_noticia">
        <span class="btn_cerrar_visualizador_noticia btn3">
            <i class="fa-solid fa-xmark"></i>
        </span>
     </div>
    
    <main>
        <section class="menu_vertical">
            <h2>A</h2>

            <div class="info_aplicacion">
                <div class="item_section active_item" id="btn_move_modul_general">
                    <p>Configuración</p>
                    <img src="IMG/icon_configuracion.png" alt="">
                </div>

                <div class="item_section" id="btn_move_modul_general">
                    <p>Noticia</p>
                    <img src="IMG/icono_noticia.png" alt="">
                </div>          
            </div>
            <hr>

            <div class="titulo_seccion_usuario">
                <p>Mis notas</p>
                <i class="fa-solid fa-caret-down"></i>
            </div>

            <div class="seccion_usuario">
                <!-- buble para mostrar los frm del usuario --> 
                <?php  
                    if (count($resultado_frm_usuario) > 0){
                    foreach($resultado_frm_usuario as $row){
                ?>
                    <div class="item_section" id="btn_mostrar_frm_usuario">
                        <p>
                            <?php echo str_replace("_" . $id_usuario,"",$row['nombre_tabla'] ) ?>
                        </p>
                        <img src="<?php echo $row['imagen_tabla'] ?>" alt="">
                        <p class="indicador_frm_usuario_bd">
                            <?php echo $row['nombre_tabla'] ?>
                        </p>
                    </div>
                <?php }} else{ ?>
                    <button class="btn_notificacion_frm_usuario">
                        <i class="fa-solid fa-plus"></i>
                        Agregar nota
                    </button>
                <?php } ?>
            </div>

            <!-- btn cerrar menu (responsive) -->
            <label for="id_menu_responsive" class="btn1 btn_cerrar_menu">
                <i class="fa-solid fa-x"></i> Cerrar
            </label>
        </section>

        <!-- Este input es para realizar la animacion del menu (responsive) -->
        <input type="checkbox" id="id_menu_responsive">

        <section class="contenedor_areas">
            <!-- Encabezado general -->
            <header class="encabezado_areas">
                <!-- Titulo de todos los frm -->
                <div class="contenedor_titulos_frm">
                    <label for="id_menu_responsive">
                        <i class="fa-solid fa-bars"></i>
                    </label>

                    <div class="subcontenedor_slider_titulos">
                        <div class="item_titulo" id="titulo_seccion_encabeza">
                            <img src="IMG/icon_configuracion.png" alt="">
                            <h3>Configuración</h3>
                        </div>
                    </div>
                </div>

                <div class="informaciones_encabezado">
                    <!-- Información de usuario -->
                    <div class="informacion_usuario">
                        <img src="<?php echo $imagen_usuario ?>" alt="imagen del usuario">

                        <label for="btn_perfil_cuenta">
                            <i class="fa-solid fa-caret-down"></i>
                        </label>
                        <input type="checkbox" id="btn_perfil_cuenta">

                        <div class="contenedor_controles_cuenta">
                            <h3><?php echo $nombre_usuario ?></h3>
                            <hr>

                            <!-- /* From Uiverse.io by zjssun */  -->
                            <a href="PHP/Paginas/pag_principal/cerrar_sesion.php?i='1'" class="btn2">
                                <i class="fa-solid fa-right-from-bracket"></i>
                                Cerrar sesión
                            </a>
                        </div>
                    </div>
                </div>
            </header>
            <hr>
            <!-- Contenedor de los distintos frm -->
            <div class="contenedor_frm" id="contenedor_frm_modulo">
                <!-- FRMS del sistema (default) -->
                <div class="configuracion" id="ancla_move_modulo">

                    <div class="diseño_tab1 encabezado_configuracion">
                        <div class="item_tab1" id="btn_move_principal_configuracion">
                            <i class="fa-solid fa-gear"></i>
                            <p>Configuración de notas</p>
                        </div>

                        <div class="item_tab1" id="btn_move_principal_configuracion">
                            <i class="fa-solid fa-brush"></i>
                            <p>Colores</p>
                        </div>

                        <div class="item_tab1" id="btn_move_principal_configuracion">
                            <i class="fa-solid fa-group-arrows-rotate fa-spin"></i>
                            <p>Animaciones</p>
                        </div>
                    </div>

                    <!-- vistas del area de configuracion -->
                    <div class="contenedor_tabs_configuracion">
                        <!-- Slider tab -->
                        <div class="slider_tab" id="slider_ventanas_configuracion">

                            <!-- Creacion de nota ** -->
                            <div class="creacion_nota">
                                <!-- Informaciones importantes de uso -->
                                <div class="contenedor_leyenda">
                                    <h2>Leyendas:</h2>
                                    <ul>
                                        <li>
                                            <div class="logo">
                                                <i class="fa-solid fa-caret-up"></i>
                                                <i class="fa-solid fa-caret-down"></i>
                                            </div>
                                            <p>Sirve para cambiar de posición las casillas.</p>              
                                        </li>

                                        <li>
                                            <div class="logo">
                                                <i class="fa-solid fa-triangle-exclamation"></i>
                                            </div>
                                            <p>No_se_puede_poner_espacio,_reemplázalo_por_guion_bajo.</p>
                                        </li>

                                        <li>
                                            <div class="logo">
                                                <i class="fa-solid fa-triangle-exclamation"></i>
                                            </div>
                                            <p>No se puede usar el mismo nombre para una nota.</p>
                                        </li>
                                    </ul>
                                </div>

                                <!-- contenedor principal (diff ventanas) -->
                                <div class="contenedor_ventanas_configuracion">
                                    <!-- Encabezado -->
                                    <div class="diseño_tab1 encabezado_creacion_nota">
                                        <div class="item_tab1" id="btn_move_creacion_frm">
                                            <i class="fa-solid fa-notes-medical"></i>
                                            <p>Nueva nota</p>
                                        </div>
                
                                        <div class="item_tab1" id="btn_move_creacion_frm">
                                            <i class="fa-solid fa-clipboard"></i>
                                            <p>Gestión de notas</p>
                                        </div>
                                    </div>

                                    <!-- Slider ventanas -->
                                    <div class="slider_ventanas">
                                        <form class="creacion_nota" id="ancla_move_creacion_frm"
                                        action="PHP/Paginas/pag_principal/crear_nota.php"
                                        method="POST" enctype="multipart/form-data">
                                            <h3>Personalización de nota</h3>

                                            <!-- Identificador de la nota (datos de la identificación de la nota) -->
                                            <div class="info_indentificador_nota">
                                                <div class="input1">
                                                    <input type="text" name="nombre_nota" placeholder="Digitar el nombre de la nota" require>
                                                </div>
                                                

                                                <div class="contenedor_logo_nota">
                                                    <div class="imagen_nota">
                                                        <p>Logo de la nota</p>
                                                        <img src="IMG/foto_base.png" alt="imagen de la nota" id="imagen_nota_configuracion">
                                                        
                                                        <input type="file" name="logo_nota" id="btn_subir_logo" require>
                                                    </div>

                                                    <label for="btn_subir_logo" class="btn_subir_logo btn1">Subir logo</label>
                                                </div>
                                            </div>

                                            <h2>Personalización de información en la Nota</h2>
                                            <!-- contenedor de las casillas que tendra la nota -->
                                            <div class="contenedor_casilla_nota">
                                            <table class="subcontenedor_casillas_nota">
                                                <thead>
                                                    <tr>
                                                        <th>Nombre de casilla</th>
                                                        <th>Tipo de casilla</th>
                                                        <th>Apariencia de la casilla</th>
                                                        <th>Opciones</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="contenedor_datos_frm">
                                                    <tr>
                                                        <th>
                                                        <div class="input1">
                                                            <input type="text" name="casilla_creacion1" placeholder="Digita el nombre">
                                                        </div>   
                                                        </th>
    
                                                        <th>
                                                            <select name="tipo_casilla1" class="select1" id="tipo_casilla_configuracion">
                                                                <option value="Texto" selected>
                                                                    Texto
                                                                </option>

                                                                <option value="Fecha">
                                                                    Fecha
                                                                </option>

                                                                <option value="Descripcion">
                                                                    Descripción
                                                                </option>
                                                            </select>
                                                        </th>
    
                                                        <th class="visualizacion">
                                                            <div class="input1">
                                                                <input type="text" name="casilla1" placeholder="Previsualización de tipo de casilla">
                                                            </div>

                                                            <input type="date" class="date1">

                                                            <textarea class="textarea1">Para describir algo</textarea>
                                                        </th>
    
                                                        <th class="controles">
                                                            <i class="fa-regular fa-trash-can"></i>

                                                            <i class="fa-solid fa-caret-up" id="btn_arriba_fila"></i>

                                                            <i class="fa-solid fa-caret-down"
                                                            id="btn_abajo_fila"></i>
                                                        </th>
                                                    </tr>
                                                </tbody>
                                            </table>
                                            
                                            <input type="button" value="Crear otra casilla" id="btn_creacion_datos_frm" class="btn1 btn_crear_casilla">
                                            </div>
                                            
                                            <input type="submit" value="📚 Crear nota" class="btn1" name="btn_creacion_nota" id="btn_creacion_nota">
                                        </form>

                                        <div class="gestion_nota">
                                            <h3>Mis Notas</h3>

                                            <!-- contenedor de las casillas que tendra la nota -->
                                            <div class="contenedor_casilla_nota">
                                                <table class="subcontenedor_casillas_nota">
                                                    <thead>
                                                        <tr>
                                                            <th>Logos</th>
                                                            <th>Nombre de las notas</th>
                                                            <th>Opciones</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr class="dato">
                                                            <th>
                                                                <img src="IMG/usuario.png" alt="">
                                                            </th>
        
                                                            <th>
                                                                <p>Gestión de contraseña</p>
                                                            </th>
        
                                                            <th class="controles">
                                                                <a href="#" class="btn1">
                                                                    <img src="IMG/icono_eliminar.png" alt="">
                                                                    
                                                                    Eliminar
                                                                </a>
                                                                <a href="#" class="btn1">
                                                                    <img src="IMG/icono_editar.png" alt="">

                                                                    Editar
                                                                </a>
                                                            </th>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Temas de la app ** -->
                            <div class="temas_app">
                                <h2>Configura el Tema Visual que Prefieras:</h2>
                                <div class="contenedor_colores">
                                    <span class="select_color" id="btn_theme"></span>
                                    <span id="btn_theme"></span>
                                    <span id="btn_theme"></span>
                                    <span id="btn_theme"></span>
                                    <span id="btn_theme"></span>
                                    <span id="btn_theme"></span>
                                </div>
                            </div>

                            <!-- Animaciones de la app ** -->
                            <div class="animaciones_app">
                                <h2>Configura el Efecto de Transición al Navegar:</h2>
                                <div class="contenedor_items_animaciones">
                                    <span class="animacion1 select_ani" id="btn_ani">
                                        <span></span>
                                    </span>
                                    <span class="animacion2" id="btn_ani">
                                        <span></span>
                                    </span>
                                    <span class="animacion3" id="btn_ani">
                                        <span></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="noticia">
                    <div class="encabezado_noticia">
                        <img src="IMG/fondo_frm_login.JPG" alt="">
                        <div class="subcontenedor_info">
                            <h2>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dignissimos possimus.</h2>

                            <button class="btn1">Ver mas <i class="fa-solid fa-angles-down"></i></button>
                        </div>
                    </div>

                    <div class="contenedor_noticias">
                        <div class="item_noticia">
                            <div class="encabezado_item">
                                <img src="IMG/fondo_frm_login.JPG" alt="">
                            </div>

                            <div class="contenido">
                                <h3>Titulo de la noticia</h3>
                                <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dignissimos labore atque ipsa harum explicabo blanditiis, molestias quo eos commodi rem id impedit at, aliquam animi odio iure officiis perferendis quod sunt. Libero esse officia provident, neque voluptates itaque error dolores. Vel, aliquam iste. Ullam temporibus, officiis reiciendis nulla exercitationem aperiam!</p>

                                <div class="control_contenido">
                                    <button class="btn1" id="btn_expandir_notcia">
                                        <i class="fa-solid fa-plus"></i>
                                        Ver mas
                                    </button>
                                </div>
                            </div>                  
                        </div>
                    </div>

                </div>

                <!-- FRM del usuario (aqui se veran todos los frm, se aplicara una busqueda y se filtrara el contenido en este frm). -->
                <div class="frm_usuario" id="frm_usuario">
                    <!-- Contenedor de botones de movimiento para el slider -->
                    <div class="diseño_tab1 encabezado_frm_usuario">
                        <div class="item_tab1" id="btn_move_frm_usuario">
                            <i class="fa-solid fa-gear"></i>
                            <p>Registro</p>
                        </div>

                        <div class="item_tab1" id="btn_move_frm_usuario">
                            <i class="fa-solid fa-brush"></i>
                            <p>Gestión de registro</p>
                        </div>
                    </div>

                    <!-- Contenedor de las dos ventanas -->
                    <div class="contenedor_slider_ventanas">
                        <!-- Slider -->
                         <div class="slider_ventanas" id="slider_frm_usuario">
                            <!-- ****** Registro ****** -->
                            <div class="registro" id="registro_frm_usuario">
                                <!-- Contenedor donde estan las casillas (inputs) -->
                                <div class="contenedor_casillas">
                                    <div class="item_contenedor">
                                        <p>Nombre:</p>
                                        <div class="input1">
                                            <input type="text" name="nombre_nota" placeholder="Digitar el nombre de la nota">
                                        </div>
                                    </div>

                                    <div class="item_contenedor">
                                        <p>Nombre:</p>
                                        <div class="input1">
                                            <input type="text" name="nombre_nota" placeholder="Digitar el nombre de la nota">
                                        </div>
                                    </div>

                                    <div class="item_contenedor">
                                        <p>Nombre:</p>
                                        <div class="input1">
                                            <input type="text" name="nombre_nota" placeholder="Digitar el nombre de la nota">
                                        </div>
                                    </div>

                                    <div class="item_contenedor">
                                        <p>Nombre:</p>
                                        <div class="input1">
                                            <input type="text" name="nombre_nota" placeholder="Digitar el nombre de la nota">
                                        </div>
                                    </div>

                                    <div class="item_contenedor">
                                        <p>Nombre:</p>
                                        <input type="date" name="nombre" class="date1">
                                    </div>

                                    <div class="item_contenedor">
                                        <p>Nombre:</p>
                                        <textarea name="descripcion" class="textarea1" placeholder="Mensaje"></textarea>
                                    </div>        
                                </div>

                                <!-- CRUD -->
                                <div class="controles_frm_crud">
                                    <button class="btn1" id="btn_guardar_datos">
                                        <i class="fa-solid fa-floppy-disk"></i>
                                        Guardar
                                    </button>
                                    <button class="btn1" id="btn_modificar_datos">
                                        <i class="fa-regular fa-pen-to-square"></i>
                                        Modificar
                                    </button>
                                </div>
                            </div>

                            <!-- ****** Gestion de registro ****** -->
                            <div class="gestion_registro" id="gestion_registro_frm_usuario">
                                <!-- Contenddor herramientas del frm (adicionales) -->
                                <div class="contenedor_herramientas_frm">

                                    <div class="buscador item_herramienta">
                                        <h2>Opciones de busqueda</h2>

                                        <div class="contenedor_casillas" id="contenedor_busqueda">
                                            <div class="input1">
                                                <input type="text" name="nombre_nota" placeholder="Digitar el valor de lo buscado">
                                            </div>

                                            <select name="buscador_opcion" class="select1">
                                                <option value="Selecciona una opción" selected disabled>Selecciona una opción</option>
                                                <option value="Nombre">Nombre</option>
                                                <option value="Apellido">Apellido</option>
                                            </select>
                                        </div>

                                        <button class="btn1" id="btn_buscar">
                                            <i class="fa-solid fa-magnifying-glass"></i>
                                            Buscar
                                        </button>
                                    </div>

                                    <div class="imprimir item_herramienta">
                                        <h2>Area de impresión</h2>

                                        <div class="contenedor_casillas">
                                            <div class="input1">
                                                <input type="text" name="nombre_nota" placeholder="Digitar el valor de lo buscado">
                                            </div>

                                            <select name="buscador_opcion" class="select1">
                                                <option value="Selecciona una opción" selected disabled>Selecciona una opción</option>
                                                <option value="Nombre">Nombre</option>
                                                <option value="Apellido">Apellido</option>
                                            </select>
                                        </div>

                                        <button class="btn1" id="btn_imprimir">
                                            <i class="fa-solid fa-print"></i>
                                            Imprimir
                                        </button>
                                    </div>
                                </div>

                                <!-- Contenedor de vista de registros -->
                                <div class="contenedor_vista_registro" id="contenedor_vista_registro">
                                    <div class="encabezado_impresion" id="encabezado_datos_impresion">
                                        <h2>[Nombre del frm]</h2>
                                        <p>05/12/2024</p>
                                    </div>

                                    <table class="subcontenedor_vista_registro" id="tabla_frm_usuario">
                                        <thead id="encabezado_vista_datos">
                                            <tr>
                                                <th>ID</th>
                                                <th>Nombre</th>
                                                <th>Apellido</th>
                                                <th>Controles</th>
                                            </tr>
                                        </thead>
                                        <tbody id="cuerpo_vista_datos">
                                            <tr class="dato">
                                                <th>
                                                    1
                                                </th>

                                                <th>
                                                    Andelson
                                                </th>

                                                <th>
                                                    Gonzalez
                                                </th>

                                                <th class="controles">
                                                    <a href="#" class="btn1">
                                                        <img src="IMG/icono_eliminar.png" alt="">                             
                                                        Eliminar
                                                    </a>

                                                    <a href="#" class="btn1">
                                                        <img src="IMG/icono_editar.png" alt="">
                                                        Editar
                                                    </a>
                                                </th>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                         </div>
                    </div>

                </div>            
            </div>
        </section>
    </main>


    <!-- Font awesomne -->
    <script src="JS/fontawesome.js" crossorigin="anonymous"></script>

    <!-- AJAX -->
    <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>

    <!-- PERSONALIZADO -->
    <script src="JS/pag_principal/animacion.js"></script>
    <script src="JS/pag_principal/notificacion.js"></script>
    <script src="JS/pag_principal/configuracion.js"></script>
    <script src="JS/pag_principal/frm_usuario.js"></script>
    <script src="JS/pag_principal/visualizador_noticia.js"></script>
    <script src="JS/pag_principal/color.js"></script>
    <script src="JS/pag_principal/mostrar_frn_usuario.js"></script>
    <script src="JS/pag_principal/eliminar.js"></script>
    <script src="JS/pag_principal/editar.js"></script>
    <script src="JS/pag_principal/guardar_datos.js"></script>
    <script src="JS/pag_principal/buscador.js"></script>
    <script src="JS/pag_principal/imprimir.js"></script>
    <script src="JS/pag_principal/movimiento_modulo.js"></script>
</body>
</html>