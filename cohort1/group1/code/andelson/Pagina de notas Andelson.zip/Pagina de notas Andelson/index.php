<?php 
    session_start();

    // datos de la cuenta del usuario
    if (isset($_SESSION['n_usuario']) and isset($_SESSION['i_usuario']) and isset($_SESSION['id_usuario'])){
        header("location: pag_principal.php");
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal notas | Andelson</title>
    <link rel="stylesheet" href="CSS/normalize.css">
    <link rel="stylesheet" href="CSS/login/estilos_generales.css">
    <link rel="stylesheet" href="CSS/login/login.css ">
    <link rel="stylesheet" href="CSS/login/notificacion.css ">

    <!-- icono de la pagina -->
    <link rel="icon" href="IMG/logo_app.ico" type="image/x-icon">
</head>
<body>

    <!-- Elementos flotantes -->   
    <section class="contenedor_elementos_desing">
        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="item1">
            <path fill="#E1543B" d="M28.6,-16.7C41.5,5.7,59.2,25.1,55.3,32.9C51.3,40.7,25.7,36.9,3.6,34.8C-18.5,32.8,-37.1,32.4,-40.8,24.8C-44.4,17.2,-33.3,2.2,-24,-18.1C-14.7,-38.4,-7.4,-64,0.3,-64.2C7.9,-64.4,15.8,-39,28.6,-16.7Z" transform="translate(100 100)" />
        </svg>

        <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg" class="item2">
            <path fill="#E5C42C" d="M39.7,-57.9C47.1,-49.3,45.8,-31.9,51.9,-16.1C58,-0.4,71.5,13.6,72.6,27.7C73.7,41.8,62.4,56,48.2,60.2C34,64.3,17,58.3,2.7,54.5C-11.5,50.7,-23.1,49.2,-34.8,44.3C-46.4,39.4,-58.2,31.1,-58.9,21C-59.5,11,-48.9,-0.7,-43.1,-12.6C-37.3,-24.4,-36.2,-36.4,-29.9,-45.4C-23.5,-54.4,-11.7,-60.4,2.2,-63.4C16.2,-66.5,32.3,-66.6,39.7,-57.9Z" transform="translate(100 100)" />
        </svg>
    </section>

    <!-- Notificación -->
    <?php if (isset($_SESSION['icono_n'])){ ?>
        <div class="capa_notificacion ani_entrada_notificacion">
            <div class="contenedor_notificacion" id="contenedor_notificacion">
                <div class="encabezado">
                    <i class="<?php echo $_SESSION['icono_n'] ?>"></i>
                    <p class="titulo"><?php echo $_SESSION['titulo_n'] ?></p>
                </div>
                
                <p class="contenido"><?php echo $_SESSION['respuesta_n'] ?></p>
                <button class="btn1" id="btn_cerrar_notificacion">Okey</button>
            </div>
        </div>
    <?php
        unset($_SESSION['icono_n'], $_SESSION['titulo_n'], $_SESSION['respuesta_n']); 
        } else { ?>
        <div class="capa_notificacion">
            <div class="contenedor_notificacion" id="contenedor_notificacion">
                <div class="encabezado">
                    <i class=""></i>
                    <p class="titulo">Titulo</p>
                </div>
                
                <p class="contenido">Contenido</p>
                <button class="btn1" id="btn_cerrar_notificacion">Aceptar</button>
            </div>
        </div>
    <?php } ?>


    <main>
        <!-- validacion de movimiento -->
        <input type="checkbox" id="btn_movimiento_registro">

        <!-- Parte izquierda -->
        <section class="parte_izquierda">
            <img src="IMG/fondo_frm_login.JPG" alt="">
        </section>

        <!-- Parte derecha -->
        <section class="parte_derecha">                     
            <form class="login" action="PHP/Paginas/login/iniciar_sesion.php" method="post">
                <div class="subcontenedor_seccion">
                    <header>
                        <img src="IMG/logo.jpg" alt="">
                        <h1>Login</h1>
                    </header>

                    <div class="informacion">
                        <div class="diseño_casilla1 elemento">
                            <i class="fa-solid fa-user"></i>
                            <input type="text" name="nombre" placeholder="Usuario o correo">
                        </div>

                        <div class="diseño_casilla1 elemento">
                            <i class="fa-solid fa-lock"></i>
                            <input type="password" name="contraseña" placeholder="Contraseña">
                        </div>
                    </div>

                    <div class="controles">
                        <input type="submit" value="Iniciar" class="btn1">
                        <label for="btn_movimiento_registro" class="btn1 btn_secundario">
                            Crear cuenta 
                            <i class="fa-solid fa-arrow-right"></i>
                        </label>
                    </div>       
                </div>
            </form>

            <form class="registro" action="PHP/Paginas/login/crear_cuenta.php" method="post" enctype="multipart/form-data">
                <div class="subcontenedor_seccion">
                    <header>
                        <img src="IMG/logo.jpg" alt="">
                        <h2>Registro</h2>
                    </header>

                    <div class="informacion">
                        <div class="diseño_casilla1 elemento">
                            <i class="fa-solid fa-user"></i>
                            <input type="text" name="nombre" placeholder="Nombre de usuario">
                        </div>

                        <div class="diseño_casilla1 elemento">
                            <i class="fa-solid fa-envelope"></i>
                            <input type="text" name="correo" placeholder="Correo electronico">
                        </div>

                        <div class="diseño_casilla1 elemento">
                            <i class="fa-solid fa-lock"></i>
                            <input type="password" name="contraseña" placeholder="Contraseña">
                        </div>
                    </div>

                    <div class="contenedor_imagen_usuario">
                        <h3>Imagen de perfil</h3>
                        <div class="contenedor_imagen">
                            <img src="IMG/foto_base.png" alt="" id="imagen_perfil">
                        </div>
                        <input type="file" name="imagen" id="btn_subir_logo">
                        <label class="btn1" for="btn_subir_logo">Subir imagen</label>
                    </div>

                    <div class="controles">
                        <input type="submit" value="Registrar" class="btn1">
                        
                        <label class="btn1 btn_secundario" for="btn_movimiento_registro">
                            <i class="fa-solid fa-arrow-left"></i>
                            Iniciar sesión                   
                        </label>
                    </div> 
                </div>
            </form>
        </section>
    </main>

    <!-- Font awesomne -->
    <script src="https://kit.fontawesome.com/7881bda97f.js" crossorigin="anonymous"></script>

    <!-- Personalizado -->
    <script src="JS/login/notificacion.js"></script>
    <script src="JS/login/imagen.js"></script>
</body>
</html>