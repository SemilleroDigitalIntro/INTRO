create database notas;
use notas;

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `contraseña` varchar(100) DEFAULT NULL,
  `correo` varchar(200) DEFAULT NULL,
  `id_unico` varchar(200) DEFAULT NULL,
  `estado` int(11) NOT NULL,
  `img` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `nombre_bd_usuario` (
  `nombre_tabla` varchar(150) DEFAULT NULL,
  `imagen_tabla` varchar(200) DEFAULT NULL,
  `nombre_campos` text DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  KEY `fk_id_user_idx` (`id_user`),
  CONSTRAINT `fk_id_user` FOREIGN KEY (`id_user`) REFERENCES `usuario` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
);