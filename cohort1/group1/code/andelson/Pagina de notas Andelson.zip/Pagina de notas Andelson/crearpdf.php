<?php
require 'vendor/autoload.php'; // Asegúrate de que el autoload de Composer esté incluido

use Dompdf\Dompdf;
use Dompdf\Options;

if (isset($_GET['contenido'])) {
    // Obtener el contenido HTML de la URL
    $html = urldecode($_GET['contenido']);

    // Crear una instancia de Dompdf
    $dompdf = new Dompdf();
    $dompdf->loadHtml($html);
    $dompdf->setPaper('A4', 'portrait'); // Configurar el tamaño de la página
    $dompdf->render();

    // Enviar el PDF al navegador
    $dompdf->stream("reporte_ventas.pdf", array("Attachment" => 0)); // Attachment=0 muestra el PDF en el navegador
} else {
    echo "No se ha recibido contenido para generar el PDF.";
}
?>

