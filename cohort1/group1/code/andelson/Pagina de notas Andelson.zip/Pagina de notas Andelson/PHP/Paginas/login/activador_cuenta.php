<?php 
    // conexion
    require_once "../../config.php";
    $db = new database();
    $conex = $db->conectar();
    session_start();


    if (isset($_GET['email'])){
        $email = $_GET['email'];
        $id_unico = $_GET['hash'];

        $query = $conex->prepare("update usuario set estado = 1 where correo = ? and id_unico = ?");

        $cmd = $query->execute([$email , $id_unico]);
           
        // preparativos para enviar el mensaje (positivo)
        $_SESSION['icono_n'] = "fa-solid fa-circle-check icono_activo";
        $_SESSION['titulo_n'] = "¡Cuenta creada con éxito!";
        $_SESSION['respuesta_n'] = "Tu cuenta ya está lista para usar. ¡Bienvenido!";
        header("location: ../../../login.php");
    }
?>