<?php 
    // preparativos
    require_once "../../config.php";
    $db = new database();
    $conex = $db->conectar();

    session_start();

    if (isset($_POST['btn_creacion_nota']) and $_SERVER['REQUEST_METHOD'] == 'POST'){
        try{
            // Imprime todo lo que se envía por POST
            // var_dump($_POST);

            $num_parametros = count($_POST);
            $id_unico = substr(uniqid(), 0, 5);

            // validación de datos
            if (isset($_POST['nombre_nota']) && !empty($_FILES['logo_nota']['tmp_name'])){
                
                $nombre_nota = $_POST['nombre_nota'] . "_" .  $_SESSION['id_usuario'];

                // primero validamos que el nombre de la nota no sea el mismo.
                $query_nota = $conex->prepare("SELECT * FROM " . $nombre_nota);
                $query_nota->execute();
                if ($query_nota->rowCount() > 0){
                    // preparando el mensaje si se encuentra algo asi
                    // preparativos para enviar el mensaje (negativo)
                    $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
                    $_SESSION['titulo_n'] = "Nota ya existente";
                    $_SESSION['respuesta_n'] = "La nota con ese nombre ya ha sido creada. Por favor, elige otro nombre.";

                    header("location: ../../../pag_principal.php");
                    exit;
                }

                $id_nota = "id_" . $nombre_nota;

                // bucles para encontrar las casillas que va a incluir la nota (dinámicamente)
                // -- nombres de casillas
                $objeto_casillas = [];
                $indice = 0;
                for ($i = 0; $i < $num_parametros; $i++){
                    $indice++;
                    if (isset($_POST['casilla_creacion' . $indice])){
                        $objeto_casillas[] = $_POST['casilla_creacion' . $indice];
                    }
            
                }

                // -- tipos de casillas
                $objeto_tipos_casillas = [];
                $indice = 0;
                for ($i = 0; $i < $num_parametros; $i++){
                    $indice++;
                    if (isset($_POST['tipo_casilla' . $indice])){
                        $objeto_tipos_casillas[] = $_POST['tipo_casilla' . $indice];
                    }
            
                }

                // -- formando nombre de los campos
                $num_casillas = count($objeto_casillas);

                $objeto_nombres_casillas = [];
                for ($x = 0; $x < $num_casillas; $x++){
                    // diferentes casos para los tipos de casillas
                    if (strtolower($objeto_tipos_casillas[$x]) == "fecha"){
                        $objeto_nombres_casillas[] = $objeto_casillas[$x] . "_f";
                    } else if (strtolower($objeto_tipos_casillas[$x]) == "descripcion"){
                        $objeto_nombres_casillas[] = $objeto_casillas[$x] . "_d";
                    } else {
                        $objeto_nombres_casillas[] = $objeto_casillas[$x];
                    }
                }

                // creando la cadena de creación de tabla
                $query_creacion_tabla = "CREATE TABLE " . $nombre_nota . " (";
                // id
                $query_creacion_tabla .= $id_nota . " INT PRIMARY KEY NOT NULL AUTO_INCREMENT";
                // bucle para las casillas (con su tipo de dato)

                foreach ($objeto_nombres_casillas as $nombre){ // corregido
                    if (substr($nombre, -2) == "_f"){
                        $query_creacion_tabla .= ", " . $nombre . " DATE NOT NULL";
                    } else {
                        $query_creacion_tabla .= ", " . $nombre . " TEXT DEFAULT NULL";
                    }
                }

                // cadena de creacion de la tabla
                $query_creacion_tabla .= ")";

                // proceso para crear la tabla
                $conex->prepare($query_creacion_tabla)->execute();

                // ahora guardar esa informacion de la tabla en una bd especifica que guarda todas las referencias creadas en base al usuario para filtrar con mas facilidad.
                
                // varibles
                $ubicacion_proxima_logo1 = "../../../imagenes_usuarios/" . $id_unico . "_" .  $_FILES['logo_nota']['name'];
                $ubicacion_proxima_logo2 = "imagenes_usuarios/" . $id_unico . "_" .  $_FILES['logo_nota']['name'];
                $ubicacion_temporal = $_FILES['logo_nota']['tmp_name'];
                $nombre_logo = $_FILES['logo_nota']['name'];

                $id_usuario = $_SESSION['id_usuario'];

                // guardando datos
                $query_guardar_referencia_tabla = $conex->prepare("INSERT INTO nombre_bd_usuario(nombre_tabla,imagen_tabla,nombre_campos,id_user) VALUE(?,?,?,?)");

                $query_guardar_referencia_tabla->bindParam(1, $nombre_nota, PDO::PARAM_STR);
                $query_guardar_referencia_tabla->bindParam(2, $ubicacion_proxima_logo2, PDO::PARAM_STR);

                // generando string con todos los campos para guardar.
                $sub_resultado_nombres_campos = "";
                foreach ($objeto_nombres_casillas as $item){
                    $sub_resultado_nombres_campos .= $item . ", ";
                }

                $resultado_nombres_campos =  $id_nota . "," . $sub_resultado_nombres_campos;

                $query_guardar_referencia_tabla->bindParam(3, $resultado_nombres_campos, PDO::PARAM_STR);

                $query_guardar_referencia_tabla->bindParam(4, $id_usuario, PDO::PARAM_STR);

                // ejecutando
                $query_guardar_referencia_tabla->execute();

                // por ultimo guardando la imagen
                move_uploaded_file($ubicacion_temporal, $ubicacion_proxima_logo1);

                // preparando mensaje (positivo)
                $_SESSION['icono_n'] = "fa-solid fa-circle-check icono_activo";
                $_SESSION['titulo_n'] = "Nota Creada Exitosamente";
                $_SESSION['respuesta_n'] = "Se ha creado una nueva nota para el usuario, ¡ya está lista para ser utilizada!";
            
                header("location: ../../../pag_principal.php");
            } else {
              // preparativos para enviar el mensaje (negativo), existe la cuenta ----
                $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
                $_SESSION['titulo_n'] = "Error en la Creación de la Nota";
                $_SESSION['respuesta_n'] = "La creación de la nota ha fallado debido a que no se completaron todos los campos requeridos. Por favor, revisa y completa la información necesaria.";

                header("location: ../../../pag_principal.php");
            }
        } catch (Exception $e){
            echo $e->getMessage();
        }
    }
?>