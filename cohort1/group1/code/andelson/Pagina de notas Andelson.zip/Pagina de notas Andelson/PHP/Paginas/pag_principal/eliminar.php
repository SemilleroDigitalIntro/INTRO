<?php

    // preparativos
    require_once "../../config.php";
    $db = new Database();
    $conex = $db->conectar();

    if (isset($_POST['nombre_tabla']) and isset($_POST['id_registro'])){
        $nombre_tabla = $_POST['nombre_tabla'];
        $id_registro = $_POST['id_registro'];
        $nombre_id = "id_" . $nombre_tabla;

        // proceso de eliminacion del registro
        // -- realizando la consulta y ejecutando
        $query_eliminar = $conex->prepare("DELETE FROM " . $nombre_tabla . " WHERE " . $nombre_id . " = ?");
        $query_eliminar->execute([$id_registro]);

        // despues de eliminar los datos, enviar datos para actualizar la tabla

        // -- consulta para mandar todos los registro
        $query_registros = $conex->prepare("SELECT * from " . $nombre_tabla);
        $query_registros->execute();
        $resultado_registros = $query_registros->fetchAll(PDO::FETCH_ASSOC);

        // -- consulta para mandar los campos
        $query_campos = $conex->prepare("SELECT nombre_campos from nombre_bd_usuario where nombre_tabla = ?");
        $query_campos->execute([$nombre_tabla]);
        $resultado_campos = $query_campos->fetch(PDO::FETCH_ASSOC);

        // mandar datos
        $respuesta = [
            'registros' => $resultado_registros,
            'campos' => $resultado_campos,
            'nombre_tabla' => $nombre_tabla
        ];

        echo json_encode($respuesta);
    }