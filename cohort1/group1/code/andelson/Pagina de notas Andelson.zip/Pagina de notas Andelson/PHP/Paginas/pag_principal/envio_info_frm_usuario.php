<?php 
    // preparativos
    require_once "../../config.php";
    $db = new database();
    $conex = $db->conectar();

    session_start();

    if (isset($_POST['nombre_tabla'])){
        $nombre_tabla = $_POST['nombre_tabla'];

        // preparando la consulta para filtrar (datos)
        $query = $conex->prepare("SELECT * FROM " . $nombre_tabla);
        $query->execute();

        $resultado_registros = $query->fetchAll(PDO::FETCH_ASSOC);

        // preparando la consulta para dar los nombres de los campos
        $query_nombre_campos = $conex->prepare("SELECT nombre_campos from nombre_bd_usuario where id_user = ? and nombre_tabla = ?");

        $query_nombre_campos->execute([$_SESSION['id_usuario'] , $nombre_tabla]);

        $resultado_campos = $query_nombre_campos->fetch(PDO::FETCH_ASSOC);

        // preparando la consulta para dar el nombre de la tabla: ----------------------
        $query_nombre_tabla = $conex->prepare("SELECT nombre_tabla from nombre_bd_usuario where id_user = ? and nombre_tabla = ?");

        $query_nombre_tabla->execute([$_SESSION['id_usuario'] , $nombre_tabla]);

        $resultado_tabla = $query_nombre_tabla->fetch(PDO::FETCH_ASSOC);

        
        // Unificar los resultados en un solo array
        $respuesta = [
            'registros' => $resultado_registros,
            'campos' => $resultado_campos,
            'nombre_tabla' => $resultado_tabla
        ];

        echo json_encode($respuesta);
    } else {
        echo "no tengo nada";
    }
?>