<?php 
    // preparativos de conexion , sesiones y referencias para envios de correos
    require_once "../../config.php";
    $db = new database();
    $conex = $db->conectar();

    session_start();
    
    if (isset($_POST['nombre']) and
        isset($_POST['contraseña']) and
        !empty($_POST['nombre']) and
        !empty($_POST['contraseña']) ){

        $nombre = $_POST['nombre'];
        $contraseña = $_POST['contraseña'];

        $query = $conex->prepare("SELECT * from usuario where nombre = ? and contraseña = ?");
        $query->execute([$nombre , $contraseña]);

        $datos_query = $query->fetch(PDO::FETCH_ASSOC);

        if ($query->rowCount() > 0){
            // guardando datos
            $_SESSION['n_usuario'] = $nombre;
            $_SESSION['i_usuario'] = $datos_query['img'];
            $_SESSION['id_usuario'] = $datos_query['id'];

            // preparativos para enviar el mensaje (positivo)
            $_SESSION['icono_n'] = "fa-solid fa-circle-check icono_activo";
            $_SESSION['titulo_n'] = "¡Bienvenido!";
            $_SESSION['respuesta_n'] = "Has iniciado sesión con éxito". " " .  $_SESSION['n_usuario'] . ". ¡Disfruta de tu experiencia!";

            header("location: ../../../pag_principal.php");
        } else {
             // preparativos para enviar el mensaje (negativo)
             $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
             $_SESSION['titulo_n'] = "Datos incorrectos";
             $_SESSION['respuesta_n'] = "El nombre o la contraseña son incorrectos. Por favor, verifica e intenta nuevamente.";
 
             header("location: ../../../index.php");
        }
    } else {
        // preparativos para enviar el mensaje (negativo), existe la cuenta ----
        $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
        $_SESSION['titulo_n'] = "Campos vacíos";
        $_SESSION['respuesta_n'] = "Por favor, completa todos los campos antes de continuar.";

        header("location: ../../../index.php");    
    }
?>