<?php 
    // preparativos de conexion , sesiones y referencias para envios de correos
    require_once "../../config.php";
    $db = new database();
    $conex = $db->conectar();

    // session_start();

    //Load Composer's autoloader
    require '../../PHPMailer/Exception.php';
    require '../../PHPMailer/PHPMailer.php';
    require '../../PHPMailer/SMTP.php';

    use PHPMailer\PHPMailer\Exception;
    use PHPMailer\PHPMailer\PHPMailer;

try{    
    // ID unico del usuario
    function generarStringAleatorio($longitud = 10) {
        $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        $stringAleatorio = '';
        $max = strlen($caracteres) - 1;
    
        for ($i = 0; $i < $longitud; $i++) {
            $stringAleatorio .= $caracteres[random_int(0, $max)];
        }
    
        return $stringAleatorio;
    }
    
    // Ejemplo de uso
    $id_unico = generarStringAleatorio();

    if (isset($_POST['nombre']) and
        isset($_POST['correo']) and
        isset($_POST['contraseña']) and
        !empty($_FILES['imagen']['tmp_name']) and
        !empty($_POST['nombre']) and
        !empty($_POST['correo']) and
        !empty($_POST['contraseña']) ){

        $nombre = $_POST['nombre'];
        $contraseña = $_POST['contraseña'];
        $correo = $_POST['correo'];
        $estado = 0;
        $nombre_imagen = "imagenes_usuarios/". $id_unico ."_". $_FILES['imagen']['name'];

        // proceso de verificacion de datos duplicados
        // (--correo)
        $query_verificacion_cuenta = $conex->prepare("SELECT * FROM usuario WHERE correo = ?");
        $query_verificacion_cuenta->execute([$correo]);

        if ($query_verificacion_cuenta->rowCount() > 0){
            // preparativos para enviar el mensaje (negativo), existe la cuenta ----
            $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
            $_SESSION['titulo_n'] = "Cuenta ya existente";
            $_SESSION['respuesta_n'] = "El correo ingresado ya está registrado. Intenta iniciar sesión o utiliza otro correo.";

            header("location: ../../../index.php");
            exit;
        }

        // (--nombre)
        $query_verificacion_cuenta_nombre = $conex->prepare("SELECT * FROM usuario WHERE nombre = ?");
        $query_verificacion_cuenta_nombre->execute([$nombre]);

        if ($query_verificacion_cuenta_nombre->rowCount() > 0){
            // preparativos para enviar el mensaje (negativo), existe la cuenta ----
            $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
            $_SESSION['titulo_n'] = "Cuenta ya existente";
            $_SESSION['respuesta_n'] = "El nombre de usuario ingresado ya está registrado. Intenta iniciar sesión o utiliza otro nombre.";

            header("location: ../../../index.php");
            exit;
        }


        $query = $conex->prepare("
        INSERT INTO usuario
        (nombre,
        contraseña,
        correo,
        id_unico,
        estado,
        img)
        VALUES
        (?,?,?,?,?,?)");

        $cmd = $query->execute([$nombre , $contraseña, $correo, $id_unico, $estado, $nombre_imagen]);

        // colocando imagen en la carpeta de imagenes
        $ubicacion_imagen_temporal = $_FILES['imagen']['tmp_name'];
        $ruta_img = "../../../imagenes_usuarios/". $id_unico . "_" . $_FILES['imagen']['name'];
        move_uploaded_file($ubicacion_imagen_temporal, $ruta_img);

        /* ---- mensaje de activacion de cuenta ---- */

        /* -- variables -- */
        $asunto = "[Nombre app] | Activación de cuenta";
        $mensaje = '
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Activación de cuenta</title>
            <style>
                *{
                box-sizing: border-box;
                margin: 0;
                padding: 0;
                color: black;
                }
    
            </style>
        </head> 
        <body>
            <div class="carta">
                <h1 style="font-size: 35px;">Empresa</h1>
                <h2 style="font-size: 30px;">[LEMA]</h2> <br>
                <hr>
        
                <p style="font-size: 24px; font-weight: bold;">Queremos expresar nuestro más sincero agradecimiento por unirte a nuestra comunidad. Valoramos profundamente tu confianza en nosotros y estamos comprometidos a proporcionarte la mejor experiencia posible. Gracias por elegirnos.</p> <br>
                <p style="font-size: 18px;">Sus datos:</p> <br>
        
                <p style="font-size: 18px;">Nombre de la cuenta: ' . $nombre . '</p> <br>
                <p style="font-size: 18px;">Contraseña: ' . $contraseña . ' </p> <br> <br>
        
                <p style="font-size: 18px;">Haga click aquí para activar su cuenta:</p> <br>
                <a style="font-size: 18px;" href="http://localhost/Pagina%20de%20notas%20Andelson/PHP/Paginas/login/activador_cuenta.php?email='.$correo.'&hash='.$id_unico.'">Activar</a>
            </div>
        </body>
        </html>';

        //Create an instance; passing `true` enables exceptions
         $mail = new PHPMailer(true);
     
         //Server settings
         $mail->SMTPDebug = 2;                      //Enable verbose debug output
         $mail->isSMTP();                                            //Send using SMTP
         $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
         $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
         $mail->Username   = 'Anderson08062006@gmail.com';                     //SMTP username
         $mail->Password   = 'bxuodyjvxriuupis';                               //SMTP password
         $mail->SMTPSecure = 'tls';            //Enable implicit TLS encryption
         $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
     
         //Recipients
         $mail->setFrom('Anderson08062006@gmail.com', 'EpicMinds Corporation');
         $mail->addAddress("$correo");     //Add a recipient
     
         //Content
         $mail->isHTML(true);   //Set email format to HTML
         $mail->CharSet = 'UTF-8';
     
         $mail->Subject = $asunto;
         $mail->Body    = $mensaje;
             
         header("location: ../../../index.php");
         $mail->send();

        // preparativos para enviar el mensaje (positivo)
        $_SESSION['icono_n'] = "fa-solid fa-circle-check icono_activo";
        $_SESSION['titulo_n'] = "¡Cuenta creada con éxito!";
        $_SESSION['respuesta_n'] = "Hemos enviado un correo para activar tu cuenta. Ábrelo y sigue las instrucciones para completar la activación.";
    } else {
        // preparativos para enviar el mensaje (negativo), existe la cuenta ----
        $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
        $_SESSION['titulo_n'] = "Campos vacíos";
        $_SESSION['respuesta_n'] = "Por favor, completa todos los campos antes de continuar.";

        header("location: ../../../index.php");   
    }
} catch (Exception $e){
    // preparativos para enviar el mensaje (negativo)
    $_SESSION['icono_n'] = "fa-solid fa-circle-xmark";
    $_SESSION['titulo_n'] = "Error al registrar la cuenta";
    $_SESSION['respuesta_n'] = "No se pudo completar el registro. Por favor, intenta nuevamente.";

    header("location: ../../../index.php");
}
?>