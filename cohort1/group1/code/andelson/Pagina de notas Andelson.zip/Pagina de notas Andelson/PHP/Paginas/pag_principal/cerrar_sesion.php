<?php 
    if (isset($_GET['i']) and isset($_GET['i']) == "1"){
        session_start();
        unset( $_SESSION['n_usuario'] ,  $_SESSION['i_usuario'] , $_SESSION['id_usuario']);
        header("location: ../../../index.php");
    }
?>