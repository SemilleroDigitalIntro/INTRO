<?php

    // preparativos
    require_once "../../config.php";
    $db = new database();
    $conex = $db->conectar(); 

    if (isset($_POST['btn_guardar']) and isset($_POST['nombre_tabla'])
    and isset($_POST['campos']) and isset($_POST['valores']) ){
        // variables
        $nombre_tabla = $_POST['nombre_tabla'];
        $campos = $_POST['campos'];
        $valores = $_POST['valores'];

        // proceso de creacion de la cadena
        $query = "INSERT INTO " . $nombre_tabla . "(";

        // -- campos
        foreach($campos as $item){
            $query .= $item . ",";
        }

        $query = substr($query, 0 , -1);
        $query .= ") VALUES(";

        // valores
        foreach($valores as $item){
            $query .= "? ,";
        }
        $query = substr($query, 0 , -1);
        $query .= ")";

        // ahora preparando la consulta
        $query_guardar = $conex->prepare($query);

        // ejecutando la consulta con los valores
        $query_guardar->execute($valores);


        // despues de guardar los datos, enviar datos para actualizar la tabla

        // -- consulta para mandar todos los registro
        $query_registros = $conex->prepare("SELECT * from " . $nombre_tabla);
        $query_registros->execute();
        $resultado_registros = $query_registros->fetchAll(PDO::FETCH_ASSOC);

        // -- consulta para mandar los campos
        $query_campos = $conex->prepare("SELECT nombre_campos from nombre_bd_usuario where nombre_tabla = ?");
        $query_campos->execute([$nombre_tabla]);
        $resultado_campos = $query_campos->fetch(PDO::FETCH_ASSOC);

        // mandar datos
        $respuesta = [
            'registros' => $resultado_registros,
            'campos' => $resultado_campos,
            'nombre_tabla' => $nombre_tabla
        ];

        echo json_encode($respuesta);
    }
