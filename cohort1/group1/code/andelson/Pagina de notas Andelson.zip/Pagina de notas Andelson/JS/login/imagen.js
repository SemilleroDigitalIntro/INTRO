// ----- funcionalidad de subir imagen
let btn_subir_logo = document.getElementById("btn_subir_logo");
let imagen_perfil = document.getElementById("imagen_perfil");
let imagen_base = "IMG/foto_base.png";

btn_subir_logo.addEventListener("change" , (e) => {
    if (e.target.files[0]){
        // condiciones para la imagen
        let imagen = e.target.files[0];
        let tipos_imagenes = ["image/jpeg" , "image/png" , "image/jpg"];
        let tamaño = imagen.size;
        let tipo = imagen.type;

        if (tamaño > 500 * 1024){
            abri_notificacion("El archivo excede el tamaño recomendado",
                "El archivo que intentas subir supera el límite recomendado de 500 KB. Por favor, selecciona un archivo más pequeño.",
                0
            );
            reset_logo_nota();
            return;
        }

        if (tipos_imagenes.includes(tipo)){} else {
            abri_notificacion("Formato de imagen no válido",
                "Solo se permiten imágenes en formato JPG, JPEG o PNG. Por favor, sube una imagen en uno de estos formatos.",
                0
            );
            reset_logo_nota();
            return;
        }

        let reader = new FileReader();
        reader.onload = function (e) {
            imagen_perfil.classList.add("animacion_carga_img");
            setTimeout(() => {
                imagen_perfil.src = e.target.result;
                imagen_perfil.classList.remove("animacion_carga_img");
            },190);
        }
        reader.readAsDataURL(e.target.files[0]);

    } else {
        reset_logo_nota();
    }
});

// funcionalidad para reestablecer el logo de la nota
function reset_logo_nota(){
    imagen_perfil.classList.add("animacion_carga_img");
    setTimeout(() => {
        imagen_perfil.src = imagen_base;
        imagen_perfil.classList.remove("animacion_carga_img");
    },190);
}