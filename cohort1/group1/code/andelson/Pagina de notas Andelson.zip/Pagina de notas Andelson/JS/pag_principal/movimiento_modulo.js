// varibles
let btn_move_modul_general = document.querySelectorAll("#btn_move_modul_general");
let ancla_move_modulo = document.getElementById("ancla_move_modulo");
let contenedor_frm_modulo = document.getElementById("contenedor_frm_modulo");
let clase_ani_nombre = "";
let titulo_seccion_encabeza = document.getElementById("titulo_seccion_encabeza");

btn_move_modul_general.forEach((item  , index) => {
    item.addEventListener("click" , () => {
        // -- cambiando el titulo al encabezado (al frm indicado)
        let nombre = item.querySelector("p").innerHTML;
        let img = item.querySelector("img").src;

        titulo_seccion_encabeza.classList.add("ani_titulo");
        setTimeout(() => {
            titulo_seccion_encabeza.classList.remove("ani_titulo");
        },300)

        setTimeout(() => {
            titulo_seccion_encabeza.querySelector("h3").innerHTML = nombre;
            titulo_seccion_encabeza.querySelector("img").src = img;
        },200)

        // indicador modulo select
        reset_select_indicador();
        item.classList.add("active_item");
        
        // moviendo modulo
        reset_select_indicador();
        item.classList.add("active_item");
        clase_ani_nombre = (id_animacion == 1) ? "ani_move_modulo1" 
        : (id_animacion == 2) ? "ani_move_modulo2" 
        : (id_animacion == 3) ? "ani_move_modulo3" : "ani_move_modulo1";

        contenedor_frm_modulo.classList.add(`${clase_ani_nombre}`);
        setTimeout(() => {
            ancla_move_modulo.style.marginLeft = `-${index}00%`;
        },300);

        setTimeout(() => {
            contenedor_frm_modulo.classList.remove(`${clase_ani_nombre}`);
        },1000);
    });
});

let btn_mostrar_frm_usuario = document.querySelectorAll("#btn_mostrar_frm_usuario");
btn_mostrar_frm_usuario.forEach((item) => {
    item.addEventListener("click" , () => {
        // -- cambiando el titulo al encabezado (al frm indicado)
        let nombre = item.querySelector("p").innerHTML;
        let img = item.querySelector("img").src;

        titulo_seccion_encabeza.classList.add("ani_titulo");
        setTimeout(() => {
            titulo_seccion_encabeza.classList.remove("ani_titulo");
        },300)

        setTimeout(() => {
            titulo_seccion_encabeza.querySelector("h3").innerHTML = nombre;
            titulo_seccion_encabeza.querySelector("img").src = img;
        },200)

        // indicador modulo select
        reset_select_indicador();
        item.classList.add("active_item");

        // moviendo modulo
        clase_ani_nombre = (id_animacion == 1) ? "ani_move_modulo1" 
        : (id_animacion == 2) ? "ani_move_modulo2" 
        : (id_animacion == 3) ? "ani_move_modulo3" : "ani_move_modulo1";

        contenedor_frm_modulo.classList.add(`${clase_ani_nombre}`);

        setTimeout(() => {
            ancla_move_modulo.style.marginLeft = `-200%`;
        },300);

        setTimeout(() => {
            contenedor_frm_modulo.classList.remove(`${clase_ani_nombre}`);
        },1000);
    });
})

function reset_select_indicador(){
    btn_mostrar_frm_usuario.forEach((item) => {
        item.classList.remove("active_item");
    })

    btn_move_modul_general.forEach((item) => {
        item.classList.remove("active_item");
    })
}