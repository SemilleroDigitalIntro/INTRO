function Btn_eliminar(){
    let btns_eliminar_registro = document.querySelectorAll("#btn_eliminar_registro");
    btns_eliminar_registro.forEach((item) => {
        item.addEventListener("click" , () => {
      
            // variables
            let nombre_tabla = item.querySelector(".indicador").innerHTML;
            let id_dato = item.closest(".dato").children[0].innerHTML;

            if (confirm("Estas seguro que quieres eliminar este registro ?")){
                $.ajax({
                    // parametros
                    url: 'PHP/Paginas/pag_principal/eliminar.php',
                    type: 'POST',
                    data: {
                        nombre_tabla: nombre_tabla,
                        id_registro: id_dato,
                    },
                    dataType: 'json',
                    success: function(response){
                        // console.log('Registros:', response.registros);
                        // console.log('Campos:', response.campos);
                        // console.log('nombre tabla:', response.nombre_tabla);
            
                        // variables
                        let nombre_tabla = response.nombre_tabla;
                        let Objeto_registros = response.registros;
                        let campos = response.campos.nombre_campos.slice(0,-2).split(',');
            
                        // despues de guardar los datos
            
                        // -- enviar un mensaje (positivo)
                        abri_notificacion("¡Éxito!" , "Los datos se han eliminado correctamente." , 1);
            
                        // -- actualizar la tabla
                        actualizar_tabla(Objeto_registros, campos, nombre_tabla);
                    },
                    error: function(xhr, status, error){
                        // errores de la solicitud AJAX
                        console.error(xhr.responseText);
                    }
                });
            }

        });
    });
}

