let btns_themes = document.querySelectorAll("#btn_theme");
btns_themes.forEach((item, index) => {
  item.addEventListener("click", () => {
    reset_seleccion_color();
    item.classList.add("select_color");
    let documento = document.documentElement;

    function cambiar_color(objeto) {
        Object.keys(objeto).forEach((color, index) => {
        documento.style.setProperty(`--color${index + 1}`, `${objeto[color]}`);
      });
    }

    let colores = [];
    switch (index) {
      case 0:
        colores = {
          1: "#fbf6ea",
          2: "#f8edeb",
          3: "#f1ddda",
          3: "#e6c1bb",
          4: "#d79c95",
          5: "#c5746e",
          6: "#ae5250",
          7: "#a04545",
          8: "#7a3739",
          9: "#6a3135",
          10: "#3a1718",
          11: "#bbdfcf",

          12: "#bbdfcf",
          13: "#2b705d",
          14: "#8ec7b2",
          15: "#225a4c",
        };

        cambiar_color(colores);
        break;
      case 1:
        colores = {
          1: "#f4faf3",
          2: "#e2f6e2",
          3: "#c7ebc7",
          4: "#9bda9b",
          5: "#67c167",
          6: "#43a542",
          7: "#369336",
          8: "#2a6b2a",
          9: "#265527",
          10: "#204722",
          11: "#0d260e",
          12: "#f8edeb",
          13: "#ae5250",
          14: "#f1ddda",
          15: "#a04545",
        };

        cambiar_color(colores);
        break;
      case 2:
        colores = {
            1: "#edf6ff",    
            2: "#d7eaff",
            3: "#b7dbff",
            4: "#86c6ff",
            5: "#4da6ff",
            6: "#2480ff",
            7: "#0d5eff",
            8: "#0647ef",
            9: "#0c3ac1",
            10: "#11379a",
            11: "#0f225c",
        
            12: "#fcf78b",
            13: "#d89607",
            14: "#fbec4e",
            15: "#c1750b" 
        };

        cambiar_color(colores);
        break;

      case 3:
        colores = {
          1: '#f7faeb',
          2: '#edf3d4',
          3: '#dbe8ae',
          4: '#c1d77f',
          5: '#a2c14b',
          6: '#8aaa38',
          7: '#6b8729',
          8: '#526823',
          9: '#435321',
          10: '#3a4720',
          11: '#1d260d',

          12: '#f6dbd2',
          13: '#bf6143',
          14: '#eec2b3',
          15: '#a04f35',
        };
    

        cambiar_color(colores);
        break;

      case 4:
        colores = {
          1: '#eeefff',
          2: '#e0e2ff',
          3: '#c8c9fd',
          4: '#a6a7fb',
          5: '#8c83f6',
          6: '#7965ef',
          7: '#6a48e3',
          8: '#5c3ac8',
          9: '#4a31a0',
          10: '#3f2f80',
          11: '#271c4a',

          12: '#ace3d4',
          13: '#28796b',
          14: '#7aceba',
          15: '#246158',
        };
    

        cambiar_color(colores);
        break;
      case 5:
        colores = {
          1: '#f8f7f7',
          2: '#f0eeee',
          3: '#dddada',
          4: '#c0b9ba',
          5: '#9d9394',
          6: '#817677',
          7: '#696060',
          8: '#564e4e',
          9: '#494343',
          10: '#353131',
          11: '#2a2727',

          12: '#eed599',
          13: '#be6621',
          14: '#e5bb64',
          15: '#9e4a1f',
        };

        cambiar_color(colores);
        break;
    }
  });
});

// funcion para seleccionar el tema indicado
function reset_seleccion_color() {
  btns_themes.forEach((item) => {
    item.classList.remove("select_color");
  });
}
