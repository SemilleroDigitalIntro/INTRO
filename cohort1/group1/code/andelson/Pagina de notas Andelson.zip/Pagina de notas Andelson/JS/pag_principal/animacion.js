let btn_ani = document.querySelectorAll("#btn_ani");
let id_animacion = 0;
btn_ani.forEach((item,index) => {
    item.addEventListener("click" , () => {
        reset_seleccion_ani();
        item.classList.add("select_ani");
       id_animacion = (index == 0) ? 1 : (index == 1) ? 2 : (index == 2) ? 3 : 0;
    });
});

function reset_seleccion_ani() {
    btn_ani.forEach((item) => {
      item.classList.remove("select_ani");
    });
}  