// funcion para mostrar los datos en el apartado de registro (para terminar de modificar)
function Btn_modificar(){
    let btns_modificar_registro = document.querySelectorAll("#btn_modificar_registro");
    btns_modificar_registro.forEach((item) => {
        item.addEventListener("click" , () => {
            // variables
            let id_dato = item.closest(".dato").children[0].innerHTML;
            let contenedor_datos = item.closest(".dato");
            let datos = [];
            let btn_modificar_datos = document.getElementById("btn_modificar_datos");

            let contenedor_casillas = document.getElementById("registro_frm_usuario").querySelector(".contenedor_casillas");

            let slider_frm_usuario = document.getElementById("slider_frm_usuario");

            // Loop to extract information
            for (let i = 1; i < contenedor_datos.children.length; i++) {
                if (contenedor_datos.children[i].classList.contains("controles")) {
                    // Skip elements with the "controles" class
                } else {
                    // Push the innerHTML of non-"controles" elements to datos
                    datos.push(contenedor_datos.children[i].innerHTML);
                }
            }

            // -- bucle para colocar datos
            for (let i = 0; i < contenedor_casillas.children.length; i++){

                // diferentes tipos de extraccion dependiendo de tipo de casilla

                // -- input: texto
                if (contenedor_casillas.children[i].querySelector(".input1")){
                    let casilla = contenedor_casillas.children[i].querySelector(".input1").children[0];
                    casilla.value = datos[i];
                }

                // -- textarea
                if (contenedor_casillas.children[i].querySelector("textarea")){
                    let casilla = contenedor_casillas.children[i].querySelector("textarea");
                    casilla.value = datos[i];
                }

                // -- input:date
                if (contenedor_casillas.children[i].querySelector(".date1")){
                    let casilla = contenedor_casillas.children[i].querySelector("input");
                    casilla.value = datos[i];
                }
            }

            // colocando el id del registro al btn de modificar
            let id_indicador = document.createElement("p");
            id_indicador.classList.add("indicador_bd_id");
            id_indicador.innerHTML = id_dato;

            btn_modificar_datos.append(id_indicador);

            // por ultimo desplazando para editar datos
            slider_frm_usuario.style.marginLeft = `0%`;
        });
    });
}

// ahora la funcionalidad para mandar la info al servidor y modificar el dato.
let btn_modificar_datos = document.getElementById("btn_modificar_datos");
btn_modificar_datos.addEventListener("click" , () => {
    let contenedor_casillas = document.getElementById("registro_frm_usuario").querySelector(".contenedor_casillas");

    // variables
    let nombre_tabla = btn_modificar_datos.querySelector(".indicador_btn_datos_tabla").innerHTML;
    let nombre_id_tbl = "id_" + nombre_tabla;
    let id_dato = btn_modificar_datos.querySelector(".indicador_bd_id").innerHTML;

    // -- variable para almacenar los diferentes datos
    let valores_casillas = [];
    let nombres_casillas = [];

     // -- bucle para recorrer todas las casillas
     for (let i = 0; i < contenedor_casillas.children.length; i++){

        // diferentes tipos de extraccion dependiendo de tipo de casilla

        // -- input: texto
        if (contenedor_casillas.children[i].querySelector(".input1")){
            let casilla = contenedor_casillas.children[i].querySelector(".input1").children[0];
            let valor_casilla = casilla.value;
            let nombre_casilla = casilla.name;

            valores_casillas.push(valor_casilla);
            nombres_casillas.push(nombre_casilla);
        }

        // -- textarea
        if (contenedor_casillas.children[i].querySelector("textarea")){
            let casilla = contenedor_casillas.children[i].querySelector("textarea");
            let valor_casilla = casilla.value;
            let nombre_casilla = casilla.name;

            valores_casillas.push(valor_casilla);
            nombres_casillas.push(nombre_casilla);
        }

        // -- input:date
        if (contenedor_casillas.children[i].querySelector(".date1")){
            let casilla = contenedor_casillas.children[i].querySelector("input");
            let valor_casilla = casilla.value;
            let nombre_casilla = casilla.name;

            valores_casillas.push(valor_casilla);
            nombres_casillas.push(nombre_casilla);
        }
    }

    // enviando al servidor para devolver la informacion y filtrar al frm del usuario
    $.ajax({
        // parametros
        url: 'PHP/Paginas/pag_principal/modificar.php',
        type: 'POST',
        data: {
            nombre_tabla: nombre_tabla,
            campos: nombres_casillas,
            valores: valores_casillas,
            id: id_dato,
            nombre_id: nombre_id_tbl
        },
        dataType: 'json',
        success: function(response){
            console.log(response.datos);
            // console.log('Registros:', response.registros);
            // console.log('Campos:', response.campos);
            // console.log('nombre tabla:', response.nombre_tabla);

            // variables
            let nombre_tabla = response.nombre_tabla;
            let Objeto_registros = response.registros;
            let campos = response.campos.nombre_campos.slice(0,-2).split(',');
            console.log(campos);

            // despues de guardar los datos

            // -- enviar un mensaje (positivo)
            abri_notificacion("¡Éxito!" , "Los datos se han modificado correctamente." , 1);

            // -- actualizar la tabla
            actualizar_tabla(Objeto_registros, campos, nombre_tabla);
        },
        error: function(xhr, status, error){
            // errores de la solicitud AJAX
            console.error(xhr.responseText);
        }
    });

});