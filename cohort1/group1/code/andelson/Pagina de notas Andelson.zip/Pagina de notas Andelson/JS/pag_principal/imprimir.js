let btn_imprimir = document.getElementById("btn_imprimir");
btn_imprimir.addEventListener("click", () => {
  // Obtener el contenido del div que deseas enviar al archivo PHP
  let contenedor_vista_registro = document.getElementById(
    "contenedor_vista_registro"
  ).innerHTML;

  let contenido = `
    <html lang="en">
    <head>
        <title>Documento</title>
        <style>

        @page {
    margin: 0;
    padding: 0;
    size: A4;
}

.select_fila{
    display: none;
}
    
body {
    font-size: 12px;
}
*{
    margin: 0;
    box-sizing: border-box;
    padding: 0;
    font-family: Arial, sans-serif;
}

table {
    width: 95%;
    border-collapse: collapse;
    margin: 0 auto;
}

table thead tr th{
    font-weight: bold;
    font-size: 20px;
}

table tbody tr{
    border-top: 2px solid rgb(97, 94, 94);
}

table tbody tr th{
    font-weight: normal;
    font-size: 18px;
}

table th, table td {
    padding: 8px;
    text-align: left;
}

table tbody th:last-child{
    display: none;
}

table thead tr th:last-child{
    display: none;
}

.encabezado_impresion{
    padding: 10px;
    background: rgb(29, 77, 126);
    color: white;
    margin-bottom: 20px;
}

.encabezado_impresion h2{
    margin-bottom: 10px;
    font-size: 30px;
}

.encabezado_impresion p{
    font-size: 20px;
}
        </style>
    </head>
    <body>
        ${contenedor_vista_registro}
    </body>
    </html>`;

  // Codificar el contenido para que sea seguro incluirlo en una URL
  let contenidoCodificado = encodeURIComponent(contenido);

  // Crear un enlace para redirigir al archivo PHP
  let redireccion = document.createElement("a");

  // Establecer el href del enlace a la URL de crearpdf.php con el contenido como parámetro
  redireccion.href = `crearpdf.php?contenido=${contenidoCodificado}`;

  // Establecer target como "_blank" para abrir el PDF en una nueva pestaña
  redireccion.target = "_blank";

  // Simular un clic en el enlace
  document.body.appendChild(redireccion);
  redireccion.click();
  document.body.removeChild(redireccion);
});
