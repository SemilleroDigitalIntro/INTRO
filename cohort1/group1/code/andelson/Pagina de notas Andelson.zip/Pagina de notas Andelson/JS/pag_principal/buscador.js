let btn_buscar = document.getElementById("btn_buscar");

btn_buscar.addEventListener("click", () => {
    // Variables
    let contenedor_busqueda = document.getElementById("contenedor_busqueda");
    let valor = contenedor_busqueda.querySelector(".input1").children[0].value.toLocaleLowerCase();

    let columna = contenedor_busqueda.querySelector(".select1");
    let valorSeleccionado = columna.value.toLocaleLowerCase();

    let encabezado_vista_datos = document.getElementById("encabezado_vista_datos");
    let cuerpo_vista_datos = document.getElementById("cuerpo_vista_datos");

    let indice_columna = -1;  // Inicializa en -1 para asegurar que se maneje el caso cuando no se encuentre

    // Si el valor de búsqueda no está vacío
    if ((valor !== "" && valor !== null) || valorSeleccionado == "todo") {
        // condicion para actualizar los datos (volver a como era antes)
        if (valorSeleccionado == "todo"){
            // Reestableciendo filas
            for (let x = 0; x < cuerpo_vista_datos.children.length; x++) {
                let fila = cuerpo_vista_datos.children[x];
                fila.classList.add("select_fila");
            }
        } else{
            // Primero capturamos la columna para buscar dentro de esa columna
            for (let i = 0; i < columna.options.length; i++) {
                if (columna.options[i].value.toLocaleLowerCase() === valorSeleccionado) {
                    indice_columna = i;
                    break;
                }
            }

            // Verificamos si la columna fue encontrada
            if (indice_columna === -1) {
                console.log("Columna no encontrada");
                return;  // Si no se encuentra la columna, salimos de la función
            }

            // Ahora buscamos los valores en esa columna
            for (let x = 0; x < cuerpo_vista_datos.children.length; x++) {
                let dato_columna = cuerpo_vista_datos.children[x].children[indice_columna].innerHTML.toLocaleLowerCase();

                let fila = cuerpo_vista_datos.children[x];

                // Comprobamos si el dato en la columna contiene el valor
                if (dato_columna.includes(valor)) {
                    fila.classList.remove("select_fila");
                } else {
                    fila.classList.add("select_fila");
                }
            }
        }
    }
});
