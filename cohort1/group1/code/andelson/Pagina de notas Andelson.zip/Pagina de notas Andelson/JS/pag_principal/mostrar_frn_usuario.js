// bucle de seleccion de todos los botones de frm
let btns_mostrar_frm_usuario = document.querySelectorAll("#btn_mostrar_frm_usuario");
btns_mostrar_frm_usuario.forEach((item) => {
    item.addEventListener("click" , () => {
        // variables para enviar al servidor (para filtrar el frm indicado)
        let nombre_tabla = item.querySelector(".indicador_frm_usuario_bd").innerHTML.trim();
        let contenedor_usuario = document.getElementById("frm_usuario");

        // contenedor
        let contenedor_registro = document.getElementById("registro_frm_usuario");
        let contenedor_gestion_registro = document.getElementById("gestion_registro_frm_usuario");

        // secciones
        let contenedor_casillas = contenedor_registro.querySelector(".contenedor_casillas");
        let contenedor_buscador = contenedor_gestion_registro.querySelector(".contenedor_herramientas_frm").querySelector(".buscador");
        let contenedor_imprimir = contenedor_gestion_registro.querySelector(".contenedor_herramientas_frm").querySelector(".imprimir");
        let encabezado_datos_impresion = document.getElementById("encabezado_datos_impresion");

        // preparativos a elementos clave para que todo funcione
        let btn_guardar_datos = document.getElementById("btn_guardar_datos");
        let btn_modificar_datos = document.getElementById("btn_modificar_datos");
        // enviando al servidor para devolver la informacion y filtrar al frm del usuario
        $.ajax({
            // parametros
            url: 'PHP/Paginas/pag_principal/envio_info_frm_usuario.php',
            type: 'POST',
            data: {
                nombre_tabla: nombre_tabla
            },
            dataType: 'json',
            success: function(response){
                setTimeout(() => {
                    // console.log('Registros:', response.registros);
                    // console.log('Campos:', response.campos);
                    // console.log('nombre tabla:', response.nombre_tabla['nombre_tabla']);
            
                    // -- proceso de colocar la informacion en el frm_usuario
                    // -- variables
                    let nombre_tabla = response.nombre_tabla['nombre_tabla'];
            
                    // -- elementos adicicionales al btn de guardar (para que tenga suficiente informacion para guardar)
                    let p_indicador_tabla_guardar = document.createElement("p");
                    p_indicador_tabla_guardar.innerHTML = nombre_tabla;
                    p_indicador_tabla_guardar.classList.add("indicador_btn_datos_tabla");

                    // Append to btn_guardar_datos
                    btn_guardar_datos.append(p_indicador_tabla_guardar);

                    // Create a separate <p> element for the second button
                    let p_indicador_tabla_modificar = document.createElement("p");
                    p_indicador_tabla_modificar.innerHTML = nombre_tabla;
                    p_indicador_tabla_modificar.classList.add("indicador_btn_datos_tabla");

                    // Append to btn_modificar_datos
                    btn_modificar_datos.append(p_indicador_tabla_modificar);

                    // agregando informacion para los datos del encabezado de la impresion
                    encabezado_datos_impresion.children[0].innerHTML = nombre_tabla.slice(0,-3);

                    const fechaLarga = new Date().toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

                    encabezado_datos_impresion.children[1].innerHTML = fechaLarga;
                    

                    // el slice funciona para que no se agrege un campo mas (que no esta en la bd).
                    let campos = response.campos.nombre_campos.slice(0,-2).split(',');

                    // condicion para saber si se encontraron los datos
                    if (campos.length > 0){
                        contenedor_casillas.innerHTML = "";
                        // proceso de colocar los inputs en el frm usuario (bucle)
                        // -- creando los elementos
                        campos.forEach((item, index) => {
                            if (index == 0){} else {
                            let contenedor_item = document.createElement("div");
                            contenedor_item.classList.add("item_contenedor");
                    
                            // condicion para saber que tipo de casilla se va a crear:
                            // -- fecha
                            if (item.trim().slice(-2).toLocaleLowerCase() == "_f"){
                                // se le aplica slice para cortar el indicador de tipo de casilla
                                let nombre_campo = item.replace(/_/g, ' ').slice(0,-2);
                                let titulo_item = document.createElement("p");
                                titulo_item.innerHTML = `${nombre_campo}:`;

                                let input = document.createElement("input");
                                input.name = item.trim();
                                input.type = "date";
                                input.classList.add("date1");

                                contenedor_item.append(titulo_item, input);
                            // -- textarea
                            } else if (item.trim().slice(-2).toLocaleLowerCase() == "_d"){
                                // se le aplica slice para cortar el indicador de tipo de casilla
                                let nombre_campo = item.replace(/_/g, ' ').slice(0,-2);
                                let titulo_item = document.createElement("p");
                                titulo_item.innerHTML = `${nombre_campo}:`;

                                let textarea = document.createElement("textarea");
                                textarea.name = item.trim();
                                textarea.classList.add("textarea1");
                                textarea.placeholder = "Digita el valor indicado";

                                contenedor_item.append(titulo_item, textarea);
                            // -- input
                            } else {
                                let nombre_campo = item.replace(/_/g, ' ');
                                let titulo_item = document.createElement("p");
                                titulo_item.innerHTML = `${nombre_campo}:`;

                                let contenedor_casilla = document.createElement("div");
                                contenedor_casilla.classList.add("input1");
                    
                                let input = document.createElement("input");
                                input.name = item.trim();
                                input.placeholder = "Digita el valor indicado";
                                input.type = "text";

                                contenedor_casilla.append(input);


                                contenedor_item.append(titulo_item, contenedor_casilla);
                            }

                            // insertando en el dom (despues de formar la estructura)
                            contenedor_casillas.append(contenedor_item);
                        }            
                        })


                        // proceso para rellenar las opciones de busqueda
                        //-- variables
                        let contenedor_select_buscador = contenedor_buscador.querySelector(".contenedor_casillas").children[1];

                        contenedor_select_buscador.innerHTML = "";
                        campos.forEach((item, index) => {
                            let identificador_tipo_casilla = item.trim().slice(-2);

                            let nombre_campo_s1 = item.replace(/_/g, ' ').slice(0,-2).trim();
                            let nombre_campo_s2 = item.replace(/_/g, ' ').trim();

                            let resultado_campo = 
                            (identificador_tipo_casilla == "_f") ? nombre_campo_s1 : 
                            (identificador_tipo_casilla == "_d") ? nombre_campo_s1 :
                            (index == 0) ? item.replace(/_/g, ' ').trim().slice(0,-3):
                            nombre_campo_s2;

                            let opcion_item = document.createElement("option");
                            opcion_item.value = resultado_campo;
                            opcion_item.innerHTML = resultado_campo;

                            contenedor_select_buscador.append(opcion_item);
                        })

                        let dato_adicional_buscador = document.createElement("option");
                        dato_adicional_buscador.value = "Todo";
                        dato_adicional_buscador.innerHTML = "Todo";
                        contenedor_select_buscador.append(dato_adicional_buscador);

                        // proceso para rellenar las opciones de imprimir
                        //-- variables
                        let contenedor_select_imprimir = contenedor_imprimir.querySelector(".contenedor_casillas").children[1];

                        contenedor_select_imprimir.innerHTML = "";
                        campos.forEach((item, index) => {
                            let identificador_tipo_casilla = item.trim().slice(-2);

                            let nombre_campo_s1 = item.replace(/_/g, ' ').slice(0,-2).trim();
                            let nombre_campo_s2 = item.replace(/_/g, ' ').trim();

                            let resultado_campo = 
                            (identificador_tipo_casilla == "_f") ? nombre_campo_s1 : 
                            (identificador_tipo_casilla == "_d") ? nombre_campo_s1 :
                            (index == 0) ? item.replace(/_/g, ' ').trim().slice(0,-3):
                            nombre_campo_s2;

                            let opcion_item = document.createElement("option");
                            opcion_item.value = resultado_campo;
                            opcion_item.innerHTML = resultado_campo;

                            contenedor_select_imprimir.append(opcion_item);
                        })

                        let dato_adicional_imprimir = document.createElement("option");
                        dato_adicional_imprimir.value = "Todo";
                        dato_adicional_imprimir.innerHTML = "Todo";
                        contenedor_select_imprimir.append(dato_adicional_imprimir);


                        // preceso para rellenar la informacion de la tabla 
                        actualizar_tabla(response.registros, campos, nombre_tabla);
                    } else {
                        return;
                    }
                }, 400)
            },
            error: function(xhr, status, error){
                // errores de la solicitud AJAX
                console.error(xhr.responseText);
            }
        });
    });
});

// funcion para actualizar la informacion de la bd
function actualizar_tabla(Objeto_registro, nombres, nombre_tabla){
    // variables
    let campos = nombres;
    // let encabezado_vista_datos = document.getElementById("encabezado_vista_datos");
    // let cuerpo_vista_datos = document.getElementById("cuerpo_vista_datos");
    let tabla_frm_usuario = document.getElementById("tabla_frm_usuario");

    tabla_frm_usuario.innerHTML = "";

    // proceso de colocar los titulos del encabezado de datos
    let contenedor_encabezado = document.createElement("thead");
    contenedor_encabezado.id = "encabezado_vista_datos";

    let cotenedor_fila_encabezado = document.createElement("tr");

    campos.forEach((titulo,index) => {
        let identificador_tipo_casilla = titulo.trim().slice(-2);

        let nombre_campo_s1 = titulo.replace(/_/g, ' ').slice(0,-2).trim();
        let nombre_campo_s2 = titulo.replace(/_/g, ' ').trim();

        let resultado_campo = 
        (identificador_tipo_casilla == "_f") ? nombre_campo_s1 : 
        (identificador_tipo_casilla == "_d") ? nombre_campo_s1 :
        (index == 0) ? titulo.replace(/_/g, ' ').trim().slice(0,-3):
        nombre_campo_s2;

        let item_encabezado = document.createElement("th");
        item_encabezado.innerHTML = resultado_campo;

        cotenedor_fila_encabezado.append(item_encabezado);
    });

    // columna adicional para colocar los controles
    let item_control_datos = document.createElement("th");
    item_control_datos.innerHTML = "Controles";
    cotenedor_fila_encabezado.append(item_control_datos);

    contenedor_encabezado.append(cotenedor_fila_encabezado);


    // proceso de vaciar los datos (en el cuerpo de la tabla)
    // -- variables
    let contenedor_cuerpo_tabla = document.createElement("tbody");
    contenedor_cuerpo_tabla.id = "cuerpo_vista_datos";

    Objeto_registro.forEach((item) => {
        // primero creamos la fila afuera para almacenar todo lo que se cree
        let contenedor_fila_cuerpo_tabla = document.createElement("tr");
        contenedor_fila_cuerpo_tabla.classList.add("dato");

        Object.keys(item).forEach((info) => {
            // realizando el bucle de las informaciones
            let item_fila = document.createElement("th");
            item_fila.innerHTML = item[info.trim()];

            // colocando dentro de la fila
            contenedor_fila_cuerpo_tabla.append(item_fila);
        });

        // pero antes de colocar todo, colocare los controles.
        let item_control = document.createElement("th");
        item_control.classList.add("controles");

        // -- btn eliminar
        let btn_eliminar = document.createElement("button");
        btn_eliminar.classList.add("btn1");
        btn_eliminar.id = "btn_eliminar_registro";

        // elementos del btn
        let img_btn_eliminar = document.createElement("img");
        img_btn_eliminar.src = "IMG/icono_eliminar.png";

        btn_eliminar.append(img_btn_eliminar , document.createTextNode(" Eliminar"));
        // requerimientos para eliminar un dato
        // nombre de la tabla y el id que quiero eliminar
        let tabla_btn_elemento = document.createElement("p");
        tabla_btn_elemento.classList.add("indicador");
        tabla_btn_elemento.innerHTML = nombre_tabla;
        btn_eliminar.append(tabla_btn_elemento);

        // -- btn editar
        let btn_modificar = document.createElement("button");
        btn_modificar.classList.add("btn1");
        btn_modificar.id = "btn_modificar_registro";

        // elementos del btn
        let img_btn_modificar = document.createElement("img");
        img_btn_modificar.src = "IMG/icono_editar.png";

        btn_modificar.append(img_btn_modificar , document.createTextNode(" Editar"));

        item_control.append(btn_eliminar, btn_modificar);

        

        contenedor_fila_cuerpo_tabla.append(item_control);

        // para al final todo lo que se almaceno en la fila se coloque en la tabla
        contenedor_cuerpo_tabla.append(contenedor_fila_cuerpo_tabla);
    })

    tabla_frm_usuario.append(contenedor_encabezado , contenedor_cuerpo_tabla);

    Btn_eliminar();
    Btn_modificar();
     // <tr class="dato">
    //     <th>
    //         1
    //     </th>

    //     <th>
    //         Andelson
    //     </th>

    //     <th>
    //         Gonzalez
    //     </th>

    //     <th class="controles">
    //         <a href="#" class="btn1">
    //             <img src="IMG/icono_eliminar.png" alt="">                             
    //             Eliminar
    //         </a>

    //         <a href="#" class="btn1">
    //             <img src="IMG/icono_editar.png" alt="">
    //             Editar
    //         </a>
    //     </th>
    // </tr>
}


// 