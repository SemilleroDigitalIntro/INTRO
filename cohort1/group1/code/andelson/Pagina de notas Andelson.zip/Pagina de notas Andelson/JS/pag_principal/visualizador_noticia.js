let visualizador_noticia = document.querySelector(".visualizador_noticia");

// funcionalidad de expandir la noticia
let btn_expandir_notcia = document.querySelectorAll("#btn_expandir_notcia");
btn_expandir_notcia.forEach((item) => {
    item.addEventListener("click" , () => {
        let contenedor_item = item.closest(".item_noticia");
        let referencia_contenedor_item = contenedor_item.cloneNode(true);
        visualizador_noticia.classList.add("animacion_entrada_visualizador");
        visualizador_noticia.append(referencia_contenedor_item);

    });
});

// funcionalidad para cerrar la noticia
let btn_cerrar_visualizador_noticia = document.querySelector(".btn_cerrar_visualizador_noticia");

btn_cerrar_visualizador_noticia.addEventListener("click" , () => {
    visualizador_noticia.classList.remove("animacion_entrada_visualizador");
    setTimeout(() => {
        let contenido_visualizador = visualizador_noticia.querySelector(".item_noticia");
        visualizador_noticia.removeChild(contenido_visualizador);
    },300);
});