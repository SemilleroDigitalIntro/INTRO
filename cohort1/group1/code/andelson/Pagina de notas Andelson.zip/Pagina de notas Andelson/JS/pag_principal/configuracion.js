
// ------------------------------------------- (encabezado de configuracion)
/* Funcionalidad de movimiento de pestaña  */
let btns_move_principal_configuracion = document.querySelectorAll("#btn_move_principal_configuracion");

let slider_ventanas_configuracion = document.getElementById("slider_ventanas_configuracion")

btns_move_principal_configuracion.forEach((item, index) => {
    item.addEventListener("click" , () => {
        slider_ventanas_configuracion.style.marginLeft = `-${index}00%` 
    });
});

/* Lo mismo pero ahora en el slider de creacion de notas */
let btns_move_creacion_frm = document.querySelectorAll("#btn_move_creacion_frm");

let ancla_move_creacion_frm = document.getElementById("ancla_move_creacion_frm")

btns_move_creacion_frm.forEach((item, index) => {
    item.addEventListener("click" , () => {
        ancla_move_creacion_frm.style.marginLeft = `-${index}00%` 
    });
});

// ---------------Fin (encabezado de configuracion) --------------------------------

// ------------------------------------------- (creacion de nota) 
/* Funcionalidad de crear un campo o casilla nueva en el frm */
// -- Variables
let contador_casillas = 1;
let validacion_creacion_casilla = 0

// - contenedor de todos los datos
let contenedor_datos_frm = document.getElementById("contenedor_datos_frm");

// -- funcion para validar si se puede crear una nueva casilla
function validar_creacion_casilla(){
    let contenedor_datos_frm2 = document.getElementById("contenedor_datos_frm");

    for (let i = 0; i < contenedor_datos_frm2.children.length; i++){
        let input = contenedor_datos_frm2.children[i].children[0].children[0].children[0]; 
        console.log(input);
        if (input.value == "" || input.value == null){
            validacion_creacion_casilla = 1;
            break;
        } else {
            validacion_creacion_casilla = 0;
        }
    }
}

// -- funcionalidad de visualizacion de tipo de casilla
function visualizacion_casilla(){
    let tipos_casillas_configuracion = document.querySelectorAll("#tipo_casilla_configuracion");

    tipos_casillas_configuracion.forEach((item) => {
        item.addEventListener("change" , () => {
            if (item.value.toLowerCase() == "fecha"){

                item.parentElement.parentElement.querySelector(".visualizacion").classList.add("visualizacion_fecha");

                item.parentElement.parentElement.querySelector(".visualizacion").classList.remove("visualizacion_descripcion");
            } else if (item.value.toLowerCase() == "descripcion") {

                item.parentElement.parentElement.querySelector(".visualizacion").classList.remove("visualizacion_fecha");

                item.parentElement.parentElement.querySelector(".visualizacion").classList.add("visualizacion_descripcion");
            } else{
                
                item.parentElement.parentElement.querySelector(".visualizacion").classList.remove("visualizacion_descripcion");

                item.parentElement.parentElement.querySelector(".visualizacion").classList.remove("visualizacion_fecha");
            }
        });
    });
}

visualizacion_casilla();

let btn_creacion_datos_frm = document.getElementById("btn_creacion_datos_frm");
btn_creacion_datos_frm.addEventListener("click" , () => {

    validar_creacion_casilla();

    if (validacion_creacion_casilla == 0){
        contador_casillas++;

        // fila
        let contenedor_datos = document.createElement("tr");
        contenedor_datos.id = `fila_frm_configuracion${contador_casillas}`;
        // estructura del dato o fila

        // -- columna 1
        let column1 = document.createElement("th");

        let contenedor_input = document.createElement("div");
        contenedor_input.classList.add("input1");

        let input = document.createElement("input");
        input.type = "text";
        input.name = `casilla_creacion${contador_casillas}`;
        input.setAttribute("placeholder", "Digita el nombre")
        contenedor_input.append(input);

        column1.append(contenedor_input);

        // -- columna 2
        let columna2  = document.createElement("th");

        let select = document.createElement("select");
        select.name = `tipo_casilla${contador_casillas}`;
        select.classList.add("select1");
        select.id = "tipo_casilla_configuracion";

        let option1 = document.createElement("option");
        option1.value = "Texto";
        option1.selected = true;
        option1.innerHTML = "Texto";

        let option2 = document.createElement("option");
        option2.value = "Fecha";
        option2.innerHTML = "Fecha";

        let option3 = document.createElement("option");
        option3.value = "Descripcion";
        option3.innerHTML = "Descripción";

        select.append(option1, option2, option3);
        columna2.append(select);


        // -- columna 3
        let column3 = document.createElement("th");   
        column3.classList.add("visualizacion");

        let contenedor_input3 = document.createElement("div");
        contenedor_input3.classList.add("input1");
        let input3 = document.createElement("input");
        input3.type = "text";
        input3.setAttribute("placeholder", "Previsualización de tipo de casilla")
        contenedor_input3.append(input3);

        let input_fecha = document.createElement("input");
        input_fecha.type = "date";
        input_fecha.classList.add("date1");

        let input_descripcion = document.createElement("textarea");
        input_descripcion.classList.add("textarea1");
        input_descripcion.innerHTML = "Para describir algo";

        column3.append(contenedor_input3, input_fecha, input_descripcion);


        // -- columna 4
        let column4 = document.createElement("th");   
        column4.classList.add("controles");

        let i1_columna4 = document.createElement("i");
        i1_columna4.setAttribute("class" , "fa-regular fa-trash-can");
        // funcionalidad de eliminar fila
        i1_columna4.addEventListener("click" , () => {
            contenedor_datos_frm.removeChild(contenedor_datos);
            reset_id();
        });

        // arriba
        let i2_columna4 = document.createElement("i");
        i2_columna4.setAttribute("class" , "fa-solid fa-caret-up");
        i2_columna4.id = "btn_arriba_fila";

        // abajo
        let i3_columna4 = document.createElement("i");
        i3_columna4.setAttribute("class" , "fa-solid fa-caret-down");
        i3_columna4.id = "btn_abajo_fila";

        column4.append(i1_columna4, i2_columna4, i3_columna4);


        contenedor_datos.append(column1, columna2, column3, column4);

        contenedor_datos.classList.add("animacion_entrada_fila_configuracion");
        contenedor_datos_frm.append(contenedor_datos);
        visualizacion_casilla();
        refrescar_movimiento_arriba();
        refrescar_movimiento_abajo();
    } else{
        abri_notificacion("Error al crear una nueva casilla" ,
        "Rellena la informacion antes de crear otra casilla.",
        0);
    }
});

// funcionalidad para refrescar movimiento 
function refrescar_movimiento_arriba(){
    // funcionalidad mover para abajo (las filas)
    let btns_arriba_fila = document.querySelectorAll("#btn_arriba_fila");

    // Asegurarnos de que estamos manejando correctamente los botones
    btns_arriba_fila.forEach((item, indice) => {
        item.addEventListener("click", () => {
            // obteniendo la fila seleccionada
            let fila_seleccionada = contenedor_datos_frm.children[indice];

            // Verifica si la fila no es la primera
            if (indice > 0) {
                // obteniendo el elemento que está arriba de la fila seleccionada
                let referencia_elemento_superior = contenedor_datos_frm.children[indice - 1];

                // Mover la fila seleccionada antes de la fila superior
                referencia_elemento_superior.before(fila_seleccionada);
            }

            refrescar_movimiento_arriba();
        });
    });
}

refrescar_movimiento_arriba();

// funcionalidad para refrescar movimiento 
function refrescar_movimiento_abajo(){
    // funcionalidad mover para arriba (las filas)
    let btns_abajo_fila = document.querySelectorAll("#btn_abajo_fila");

    // Asegurarnos de que estamos manejando correctamente los botones
    btns_abajo_fila.forEach((item, indice) => {
        item.addEventListener("click", () => {
            // obteniendo la fila seleccionada
            let fila_seleccionada = contenedor_datos_frm.children[indice];

            // Verifica si la fila no es la primera
            if (contenedor_datos_frm.children[indice + 1]) {
                // obteniendo el elemento que está abajo de la fila seleccionada
                let referencia_elemento_superior = contenedor_datos_frm.children[indice + 1];

                // Mover la fila seleccionada antes de la fila superior
                referencia_elemento_superior.after(fila_seleccionada);
            }

            refrescar_movimiento_abajo();
        });
    });
}

refrescar_movimiento_abajo();


// Resetear id de las filas (nombre para php)
function reset_id(){
    for (let i = 0; i < contenedor_datos_frm.children.length; i++){
        let input = contenedor_datos_frm.children[i].children[0].children[0].children[0];
        let select = contenedor_datos_frm.children[i].children[1].children[0];

        input.name = `casilla_creacion${i + 1}`;
        select.name = `tipo_casiila${i + 1}`;       
    }
} 

// ----- funcionalidad de subir imagen
let btn_subir_logo = document.getElementById("btn_subir_logo");
let imagen_nota_logo = document.getElementById("imagen_nota_configuracion");
let imagen_base = "IMG/foto_base.png";

btn_subir_logo.addEventListener("change" , (e) => {
    if (e.target.files[0]){
        // condiciones para la imagen
        let imagen = e.target.files[0];
        let tipos_imagenes = ["image/jpeg" , "image/png" , "image/jpg"];
        let tamaño = imagen.size;
        let tipo = imagen.type;

        if (tamaño > 500 * 1024){
            abri_notificacion("El archivo excede el tamaño recomendado",
                "El archivo que intentas subir supera el límite recomendado de 500 KB. Por favor, selecciona un archivo más pequeño.",
                0
            );
            reset_logo_nota();
            return;
        }

        if (tipos_imagenes.includes(tipo)){} else {
            abri_notificacion("Formato de imagen no válido",
                "Solo se permiten imágenes en formato JPG, JPEG o PNG. Por favor, sube una imagen en uno de estos formatos.",
                0
            );
            reset_logo_nota();
            return;
        }

        let reader = new FileReader();
        reader.onload = function (e) {
            imagen_nota_logo.classList.add("animacion_carga_img");
            setTimeout(() => {
                imagen_nota_logo.src = e.target.result;
                imagen_nota_logo.classList.remove("animacion_carga_img");
            },190);
        }
        reader.readAsDataURL(e.target.files[0]);

    } else {
        reset_logo_nota();
    }
});

// funcionalidad para reestablecer el logo de la nota
function reset_logo_nota(){
    imagen_nota_logo.classList.add("animacion_carga_img");
    setTimeout(() => {
        imagen_nota_logo.src = imagen_base;
        imagen_nota_logo.classList.remove("animacion_carga_img");
    },190);
}


// funcionalidad antes de crear una nota (verificar si esta todo validado)
let btn_creacion_nota = document.createElement("btn_creacion_nota");
btn_creacion_nota.addEventListener("click" , (e) => {
    e.preventDefault();
    validar_creacion_casilla();

    if (validacion_creacion_casilla == 1){
        abri_notificacion("Error en la Creación de la Nota", "No se puede crear la nota porque faltan datos. Por favor, completa toda la información necesaria." , 0);
    } else {
        let frm = document.getElementById("ancla_move_creacion_frm");
        frm.submit();
    }
});

