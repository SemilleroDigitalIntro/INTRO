let btn_guardar_datos = document.getElementById("btn_guardar_datos");


btn_guardar_datos.addEventListener("click" , () => {
    let contenedor_registro = document.getElementById("registro_frm_usuario");
    let contenedor_casillas = contenedor_registro.querySelector(".contenedor_casillas");

    // proceso de recolecion de datos

    let nombre_tabla = btn_guardar_datos.querySelector("p").innerHTML;

    // -- variable para almacenar los diferentes datos
    let valores_casillas = [];
    let nombres_casillas = [];

    // -- bucle para recorrer todas las casillas
    for (let i = 0; i < contenedor_casillas.children.length; i++){

        // diferentes tipos de extraccion dependiendo de tipo de casilla

        // -- input: texto
        if (contenedor_casillas.children[i].querySelector(".input1")){
            let casilla = contenedor_casillas.children[i].querySelector(".input1").children[0];
            let valor_casilla = casilla.value;
            let nombre_casilla = casilla.name;

            valores_casillas.push(valor_casilla);
            nombres_casillas.push(nombre_casilla);
        }

        // -- textarea
        if (contenedor_casillas.children[i].querySelector("textarea")){
            let casilla = contenedor_casillas.children[i].querySelector("textarea");
            let valor_casilla = casilla.value;
            let nombre_casilla = casilla.name;

            valores_casillas.push(valor_casilla);
            nombres_casillas.push(nombre_casilla);
        }

        // -- input:date
        if (contenedor_casillas.children[i].querySelector(".date1")){
            let casilla = contenedor_casillas.children[i].querySelector("input");
            let valor_casilla = casilla.value;
            let nombre_casilla = casilla.name;

            valores_casillas.push(valor_casilla);
            nombres_casillas.push(nombre_casilla);
        }
    }

    // enviando al servidor para devolver la informacion y filtrar al frm del usuario
    $.ajax({
        // parametros
        url: 'PHP/Paginas/pag_principal/guardar.php',
        type: 'POST',
        data: {
            nombre_tabla: nombre_tabla,
            campos: nombres_casillas,
            valores: valores_casillas,
            btn_guardar: "si"
        },
        dataType: 'json',
        success: function(response){
            // console.log('Registros:', response.registros);
            // console.log('Campos:', response.campos);
            // console.log('nombre tabla:', response.nombre_tabla);

            // variables
            let nombre_tabla = response.nombre_tabla;
            let Objeto_registros = response.registros;
            let campos = response.campos.nombre_campos.slice(0,-2).split(',');
            console.log(campos);

            // despues de guardar los datos

            // -- enviar un mensaje (positivo)
            abri_notificacion("¡Éxito!" , "Los datos se han guardado correctamente." , 1);

            // -- actualizar la tabla
            actualizar_tabla(Objeto_registros, campos, nombre_tabla);
        },
        error: function(xhr, status, error){
            // errores de la solicitud AJAX
            console.error(xhr.responseText);
        }
    });
});