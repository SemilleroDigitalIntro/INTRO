// funcionalidad de movimiento de las diferentes ventanas del frm del usuario
let btns_move_frm_usuario = document.querySelectorAll("#btn_move_frm_usuario");
let slider_frm_usuario = document.getElementById("slider_frm_usuario");
btns_move_frm_usuario.forEach((item, index) => {
    item.addEventListener("click" , () => {
        slider_frm_usuario.style.marginLeft = `-${index}00%`;
    });
});